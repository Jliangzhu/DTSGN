# tool.py
import torch
import numpy as np
from config import get_config
from sklearn.metrics import mean_squared_error, r2_score

args = get_config()


def MSE(predictions, targets):
    """Calculate Root Mean Square Error"""
    criterion = torch.nn.MSELoss()
    return criterion(predictions, targets)


def evaluate_metrics(actual, predicted):
    """Calculate evaluation metrics"""
    return [
        np.sqrt(mean_squared_error(actual, predicted)),
        r2_score(actual, predicted)
    ]


def kernel(X, X2, gamma=0.4):
    '''
    Input: X  Size1*n_feature
           X2 Size2*n_feature
    Output: Size1*Size2
    '''
    X = X.to(args.device)
    X2 = X2.to(args.device)

    X = torch.transpose(X, 1, 0)
    X2 = torch.transpose(X2, 1, 0)

    n1, n2 = X.shape[1], X2.shape[1]
    n1sq = torch.sum(X ** 2, 0).float().to(args.device)
    n2sq = torch.sum(X2 ** 2, 0).float().to(args.device)

    D = torch.ones((n1, n2), device=args.device) * n2sq + \
        torch.transpose(torch.ones((n2, n1), device=args.device) * n1sq, 1, 0) - \
        2 * torch.mm(torch.transpose(X, 1, 0), X2)

    K = torch.exp(-gamma * D)
    return K


def conditional_kernel(X_p_list, Y_p, X_q_list, Y_q, lamda=1):
    '''
    dim(X_p_list) = dim(X_q_list) = layer_num*Size*n_feature
    '''
    layer_num = 2
    out = torch.tensor(0.0, device=args.device)

    for i in range(layer_num):
        X_p = X_p_list[i].to(args.device)
        X_q = X_q_list[i].to(args.device)
        Y_p = Y_p.to(args.device)
        Y_q = Y_q.to(args.device)

        np = X_p.shape[0]
        nq = X_q.shape[0]
        I1 = torch.eye(np, device=args.device)
        I2 = torch.eye(nq, device=args.device)

        Kxpxp = kernel(X_p, X_p)
        Kxqxq = kernel(X_q, X_q)
        Kxqxp = kernel(X_q, X_p)

        Kypyq = kernel(Y_p, Y_q)
        Kyqyq = kernel(Y_q, Y_q)
        Kypyp = kernel(Y_p, Y_p)

        a = torch.mm(torch.inverse(Kxpxp + np * lamda * I1), Kypyp)
        b = torch.mm(a, torch.inverse(Kxpxp + np * lamda * I1))
        c = torch.mm(b, Kxpxp)
        out1 = torch.trace(c)

        a1 = torch.mm(torch.inverse(Kxqxq + nq * lamda * I2), Kyqyq)
        b1 = torch.mm(a1, torch.inverse(Kxqxq + nq * lamda * I2))
        c1 = torch.mm(b1, Kxqxq)
        out2 = torch.trace(c1)

        a2 = torch.mm(torch.inverse(Kxpxp + np * lamda * I1), Kypyq)
        b2 = torch.mm(a2, torch.inverse(Kxqxq + nq * lamda * I2))
        c2 = torch.mm(b2, Kxqxp)
        out3 = torch.trace(c2)

        out += (out1 + out2 - 2 * out3)

    return out
