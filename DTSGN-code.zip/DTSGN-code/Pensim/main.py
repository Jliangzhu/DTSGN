# main.py
import os
import torch
from model import SGN
from config import get_config
import torch.utils.data as Data
from data_loader import DataProcessor
from utils import SequenceGenerator, train_loop, DTSGN


def prepare_data(processor, args):
    """
    Preprocess and create sequences for source and target domains.
    """
    source_train_data, source_train_labels = processor.preprocess_source_data(
        processor.load_source_dataset(os.path.join(args.data_dir, 'mode_1.txt')))

    seq_data, seq_label = SequenceGenerator.create_sequences(source_train_data, source_train_labels, args.seq_length)
    train_data_loader = Data.DataLoader(dataset=seq_data, batch_size=args.batch_size, num_workers=0, shuffle=False, drop_last=True)
    train_label_loader = Data.DataLoader(dataset=seq_label, batch_size=args.batch_size, num_workers=0, shuffle=False, drop_last=True)

    target_train_data, target_train_labels, target_test_data, target_test_labels = processor.preprocess_target_data(
        processor.load_target_dataset(os.path.join(args.data_dir, 'mode_2.txt')))

    seq_train_data, seq_train_label = SequenceGenerator.create_sequences(target_train_data, target_train_labels, args.seq_length)
    seq_test_data, seq_test_label = SequenceGenerator.create_sequences(target_test_data, target_test_labels, args.seq_length)

    return train_data_loader, train_label_loader, seq_train_data, seq_train_label, seq_test_data, seq_test_label


def model_train(model, train_data_loader, train_label_loader, seq_train_data, seq_train_label, seq_test_data):
    """
    Train the model.
    """
    train_loop(model, train_data_loader, train_label_loader)
    DTSGN(model, seq_train_data, seq_train_label, seq_test_data)


def save_model(model):
    """
    Save the trained model.
    """
    model.eval()
    torch.save(model.state_dict(), "./output/model.pt")


def main():
    """
    Domain Transfer Spatiotemporal Graph Model.
    """
    args = get_config()

    processor = DataProcessor()
    train_data_loader, train_label_loader, seq_train_data, seq_train_label, seq_test_data, seq_test_label = prepare_data(processor, args)

    model = SGN(args.num_nodes)

    # Train the model
    model_train(model, train_data_loader, train_label_loader, seq_train_data, seq_train_label, seq_test_data)

    # Save the trained model
    save_model(model)


if __name__ == "__main__":
    main()
