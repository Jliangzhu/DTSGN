# model.py
import torch
import torch.nn as nn
from config import get_config

args = get_config()


def calculate_laplacian_with_self_loop(adj_matrix):
    adj_matrix = adj_matrix + torch.eye(adj_matrix.size(0), device=args.device)
    row_sum = adj_matrix.sum(1)
    d_inv_sqrt = torch.pow(row_sum, -0.5).flatten()
    d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.0
    d_mat_inv_sqrt = torch.diag(d_inv_sqrt)
    normalized_laplacian = (
        adj_matrix.matmul(d_mat_inv_sqrt).transpose(0, 1).matmul(d_mat_inv_sqrt)
    )
    return normalized_laplacian


class GraphMasking(nn.Module):
    def __init__(self, num_nodes, mask_prob=0.01):
        super(GraphMasking, self).__init__()
        self.mask_prob = mask_prob
        self.mask = nn.Parameter(torch.ones(num_nodes, num_nodes, device=args.device))

    def forward(self, edge_index):
        prob_matrix = torch.full_like(self.mask, self.mask_prob)
        mask = torch.bernoulli(prob_matrix)
        masked_edges = edge_index + mask
        return masked_edges


class SpatioTemporalGraphConvolution(nn.Module):
    def __init__(self, adjacency_matrix, num_gru_units: int, output_dim: int, bias: float = 0.0):
        super(SpatioTemporalGraphConvolution, self).__init__()
        self.num_gru_units = num_gru_units
        self.output_dim = output_dim
        self.bias_init_value = bias
        self.adjacency_matrix = adjacency_matrix
        self.weights = nn.Parameter(
            torch.FloatTensor(self.num_gru_units + 1, self.output_dim).to(args.device)
        )
        self.mask = GraphMasking(args.num_nodes, mask_prob=0.01)
        self.biases = nn.Parameter(torch.FloatTensor(self.output_dim).to(args.device))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weights)
        nn.init.constant_(self.biases, self.bias_init_value)

    def forward(self, node_features, hidden_state):
        batch_size, num_nodes = node_features.shape
        node_features = node_features.reshape((batch_size, num_nodes, 1))
        hidden_state = hidden_state.reshape(
            (batch_size, num_nodes, self.num_gru_units)
        )
        concatenation = torch.cat((node_features, hidden_state), dim=2)
        concatenation = concatenation.transpose(0, 1).transpose(1, 2)
        concatenation = concatenation.reshape(
            (num_nodes, (self.num_gru_units + 1) * batch_size)
        )

        matrix1 = self.adjacency_matrix

        if self.training:
            matrix1 = self.mask(matrix1)

        matrix = matrix1 + torch.eye(matrix1.size(0), device=args.device)
        row_sum = matrix.sum(1)
        d_inv_sqrt = torch.pow(row_sum, -0.5).flatten()
        d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.0
        d_mat_inv_sqrt = torch.diag(d_inv_sqrt)
        normalized_laplacian = (
            matrix.matmul(d_mat_inv_sqrt).transpose(0, 1).matmul(d_mat_inv_sqrt)
        )

        a_times_concat = normalized_laplacian @ concatenation
        a_times_concat = a_times_concat.reshape(
            (num_nodes, self.num_gru_units + 1, batch_size)
        )
        a_times_concat = a_times_concat.transpose(0, 2).transpose(1, 2)
        a_times_concat = a_times_concat.reshape(
            (batch_size * num_nodes, self.num_gru_units + 1)
        )
        outputs = a_times_concat @ self.weights + self.biases
        outputs = outputs.reshape((batch_size, num_nodes, self.output_dim))
        outputs = outputs.reshape((batch_size, num_nodes * self.output_dim))
        return outputs, matrix1


class SpatioTemporalGraphGRUCell(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int):
        super(SpatioTemporalGraphGRUCell, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.adjacency_matrix = nn.Parameter(torch.FloatTensor(torch.rand(args.num_nodes, args.num_nodes) + 1e-1).to(args.device))
        self.adjacency_matrix.register_hook(lambda grad: self.apply_constraints())
        self.graph_conv1 = SpatioTemporalGraphConvolution(self.adjacency_matrix,
             self.hidden_dim, self.hidden_dim * 2, bias=1.0
        )
        self.graph_conv2 = SpatioTemporalGraphConvolution(self.adjacency_matrix,
             self.hidden_dim, self.hidden_dim
        )

    def apply_constraints(self):
        with torch.no_grad():
            self.adjacency_matrix[self.adjacency_matrix < 0] = 0

    def forward(self, node_features, hidden_state):
        graph_output, _ = self.graph_conv1(node_features, hidden_state)
        concatenation = torch.sigmoid(graph_output)
        reset_gate, update_gate = torch.chunk(concatenation, chunks=2, dim=1)
        graph_output, _ = self.graph_conv2(node_features, reset_gate * hidden_state)
        candidate_state = torch.tanh(graph_output)
        new_hidden_state = update_gate * hidden_state + (1.0 - update_gate) * candidate_state
        return new_hidden_state, new_hidden_state, _


class SGN(nn.Module):
    def __init__(self, hidden_dim: int):
        super(SGN, self).__init__()
        self.input_dim = args.num_nodes
        self.hidden_dim = hidden_dim
        self.stgcn_cell = SpatioTemporalGraphGRUCell(self.input_dim, self.hidden_dim).to(args.device)

        self.fc1 = nn.Linear(64, 60).to(args.device)
        self.fc2 = nn.Linear(60, 60).to(args.device)
        self.fc3 = nn.Linear(60, 30).to(args.device)
        self.predict = nn.Linear(30, 1).to(args.device)
        self.relu = nn.ReLU()

    def forward(self, node_features):
        node_features = node_features.to(args.device)
        batch_size, seq_len, num_nodes = node_features.shape
        hidden_state = torch.zeros(batch_size, num_nodes * self.hidden_dim).to(args.device)
        output = None
        adj = None

        for i in range(seq_len):
            output, hidden_state, adj = self.stgcn_cell(node_features[:, i, :], hidden_state)

        output = output.view(node_features.size(0), -1)
        x = self.fc1(output)
        inter_x1 = self.relu(x)
        x = self.fc2(inter_x1)
        inter_x2 = self.relu(x)
        x = self.fc3(inter_x2)
        inter_x3 = self.relu(x)
        result = self.predict(inter_x3)

        target_list = list([inter_x1, inter_x2, inter_x3])

        return result, adj, target_list
