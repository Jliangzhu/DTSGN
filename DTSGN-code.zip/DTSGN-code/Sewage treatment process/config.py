# config.py
import argparse

def get_config():

    # Argument parser setup
    parser = argparse.ArgumentParser(description='DTSGN Training')
    parser.add_argument('--device', type=str, default='cpu', help='CPU device')
    parser.add_argument('--s_epochs', type=int, default=200,
                        help='Number of training epochs in source domain')
    parser.add_argument('--t_epochs', type=int, default=60,
                        help='Number of training epochs in target domain')
    parser.add_argument('--batch_size', type=int, default=20, help='Batch size')
    parser.add_argument('--seq_length', type=int, default=3, help='Sliding window')
    parser.add_argument('--num_nodes', type=int, default=8, help='The number of nodes')
    parser.add_argument('--learning_rate', type=float, default=1e-3, help='Learning rate')
    parser.add_argument('--entropy_coefficient', type=float, default=1e-3, help='Entropy')
    parser.add_argument('--cdc_coefficient', type=float, default=0.1, help='CDA loss coefficient')
    parser.add_argument('--data_dir', type=str, default='./data/',
                        help='Path to dataset directory')
    parser.add_argument('--output_dir', type=str, default='./output/',
                        help='Path to save dataset directory')

    # Parse arguments
    args = parser.parse_args()

    return args
