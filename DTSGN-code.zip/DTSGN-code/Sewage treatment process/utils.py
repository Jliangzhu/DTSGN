# utils.py
import torch
import numpy as np
from tqdm import tqdm
from config import get_config
from tool import conditional_kernel, MSE

args = get_config()


class SequenceGenerator:
    """Handles temporal sequence generation"""

    @staticmethod
    def create_sequences(features: np.ndarray,
                         targets: np.ndarray,
                         seq_length: int) -> tuple:
        """Generate sliding window sequences"""
        combined = np.hstack((features, targets))
        sequences = np.array([combined[i:i + seq_length]
                              for i in range(len(combined) - seq_length + 1)])
        return (
            torch.FloatTensor(sequences[:, :, :-1]),
            torch.FloatTensor(sequences[:, -1, -1].reshape(-1, 1)))


def train_loop(model, data_loader, label_loader):

    model.train()
    train_losses = []
    opt = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    for epoch in range(args.s_epochs):
        epoch_loss = 0
        progress_bar = tqdm(zip(data_loader, label_loader),
                            total=len(data_loader),
                            desc=f'Epoch {epoch + 1}/{args.s_epochs}',
                            ncols=100)

        for batch1, batch2 in progress_bar:
            data = batch1.to(args.device)
            label = batch2.to(args.device)

            opt.zero_grad()
            out, adj, _ = model(data)

            entropy = -adj * torch.log(torch.sigmoid(adj)) - (1 - adj) * torch.log(
                1 - torch.sigmoid(adj))

            loss = MSE(out, label) + args.entropy_coefficient * torch.mean(entropy)

            loss.backward()
            opt.step()
            epoch_loss += loss.item()

            progress_bar.set_postfix({'Loss': loss.item()})

        epoch_loss /= len(data_loader)
        train_losses.append(epoch_loss)


def DTSGN(model, t_xtrain, t_ytrain, t_xtest):
    """"The inclusion of the perturbation graph in the target domain can be tailored to specific cases"""

    model.eval()
    namelist = ['predict.weight', 'predict.bias', 'fc3.weight', 'fc3.bias', 'fc2.weight', 'fc2.bias', 'fc1.weight',
                'fc1.bias']

    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)

    for name, value in model.named_parameters():
        if name in namelist:
            value.requires_grad = True
        else:
            value.requires_grad = False

    with tqdm(range(args.t_epochs), desc=f"Epoch {args.t_epochs + 1}/{args.t_epochs}", unit="epoch") as pbar:
        for epoch in pbar:
            prediction, adj_t, A_t = model(t_xtrain.to(args.device))

            with torch.no_grad():
                s_ypred, adj_s, A_s = model(t_xtest.to(args.device))

            CDA_loss = conditional_kernel(A_t, t_ytrain.to(args.device), A_s, s_ypred)
            Loss = MSE(prediction, t_ytrain.to(args.device)) + args.cdc_coefficient * CDA_loss

            optimizer.zero_grad()
            Loss.backward()

            optimizer.step()
            pbar.set_description(f"Epoch {epoch + 1}/{args.t_epochs}")