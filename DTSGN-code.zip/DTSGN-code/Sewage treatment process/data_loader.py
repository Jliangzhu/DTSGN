# data_loader.py
import numpy as np
from sklearn.preprocessing import MinMaxScaler


class DataProcessor:
    """Handles data loading and preprocessing"""

    def __init__(self):

        self.scalers_source_label = MinMaxScaler()

        self.scalers_target_label = MinMaxScaler()

    def load_source_dataset(self, file_path):
        """Load dataset from .txt file"""
        data = np.loadtxt(file_path, delimiter=',')
        return data

    def load_target_dataset(self, file_path):
        """Load dataset from .txt file"""
        data = np.loadtxt(file_path, delimiter=',')
        return data

    def preprocess_source_data(self, data):
        """Preprocess data with normalization"""
        features = data[:, :-1]
        targets = data[:, -1].reshape(-1, 1)

        scaled_targets = self.scalers_source_label.fit_transform(targets)

        return features, scaled_targets

    def preprocess_target_data(self, data):
        """Preprocess data with normalization"""
        features = data[:, :-1]
        targets = data[:, -1].reshape(-1, 1)

        index1 = np.load('index1.npy')
        index2 = np.load('index2.npy')

        # Feature
        scaled_t_xtrain, scaled_t_xtest = features[index1,:], features[index2,:]

        # Target scaling
        t_ytrain, t_ytest = targets[index1,:], targets[index2,:]

        scaled_t_ytrain = self.scalers_target_label.fit_transform(t_ytrain)

        return scaled_t_xtrain, scaled_t_ytrain, scaled_t_xtest, t_ytest


